public class CartaoBasico extends CartaoDeCredito {

    public CartaoBasico(String numero, float limiteInicial) {
        super(numero, limiteInicial);
    }

    @Override
    public void realizarTransacao(float valor, String descricao, boolean comCashback) {
        super.realizarTransacao(valor, descricao, false);
    }
}