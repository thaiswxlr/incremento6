public class CartaoEmpresarial extends CartaoDeCredito {

    public CartaoEmpresarial(String numero, float limiteInicial) {
        super(numero, limiteInicial);
        setLimite(limiteInicial + 10000); 
    }

    public void realizarTransacaoParcelada(float valor, int parcelas, String descricao) {
        if (parcelas <= 0) {
            System.out.println("O número de parcelas deve ser maior que zero.");
            return;
        }
        float valorParcela = valor / parcelas;
        if (valorParcela > getLimite()) {
            System.out.println("Limite insuficiente para realizar a transação parcelada.");
        } else {
            for (int i = 0; i < parcelas; i++) {
                realizarTransacao(valorParcela, descricao + " - Parcela " + (i + 1), false);
            }
            System.out.printf("Transação parcelada em %d vezes no valor de R$%.2f cada.%n", parcelas, valorParcela);
        }
    }
}