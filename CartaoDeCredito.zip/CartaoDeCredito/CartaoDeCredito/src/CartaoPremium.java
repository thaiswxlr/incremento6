public class CartaoPremium extends CartaoDeCredito {

    public CartaoPremium(String numero, float limiteInicial, float cashbackRate) {
        super(numero, limiteInicial, cashbackRate);
        setLimite(limiteInicial + 5000); 
    }

    @Override
    public void realizarTransacao(float valor, String descricao, boolean comCashback) {
        super.realizarTransacao(valor, descricao, comCashback);
    }
}